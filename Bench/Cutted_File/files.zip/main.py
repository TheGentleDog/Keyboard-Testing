# =============================================================================
# main.py — Entry point for the Filipino Gaze-Based Keyboard
# =============================================================================

from model import ngram_model
from ui import FilipinoKeyboard

if __name__ == "__main__":
    print("=" * 60)
    print("FILIPINO KEYBOARD - LIVE AUTOCOMPLETE VERSION")
    print("Gaze-Based Digital Keyboard")
    print("=" * 60)

    if not ngram_model.load_cache():
        print("\nNo cache found. Building from built-in vocabulary...")
        ngram_model.train_from_builtin()
        ngram_model.save_cache()

    print("\nLoading user learning...")
    ngram_model.load_user_learning()

    app = FilipinoKeyboard()
    app.mainloop()
